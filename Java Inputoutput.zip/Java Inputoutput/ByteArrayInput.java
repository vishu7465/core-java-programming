import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteArrayInput {

	public static void main(String h[]) throws IOException {
		
		ByteArrayOutputStream u=new ByteArrayOutputStream();
		FileOutputStream f=new FileOutputStream("d://temp.txt");
		String h1="helooooooooo";
		byte[]i=h1.getBytes();
	f.write(i);
	
	}
	
}
