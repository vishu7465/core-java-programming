import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteInput {
public static void main(String h[]) throws IOException {
	
	

	ByteArrayOutputStream u=new ByteArrayOutputStream();
	FileOutputStream f=new FileOutputStream("d://temp.txt");
	String h1="helooooooooo";
	byte[]i=h1.getBytes();
f.write(i);
	
	ByteArrayInputStream i1=new ByteArrayInputStream(i);
	FileInputStream ui=new FileInputStream("d://temp.txt");
int i3=0;
while((i3=ui.read())!=-1) {
	
	System.out.print((char)i3);
		
		
		
	}
	
	
}
}
