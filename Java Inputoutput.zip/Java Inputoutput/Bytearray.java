package exammm;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Bytearray {
public static void main(String h[]) throws IOException {

	
	 ByteArrayOutputStream bb=new ByteArrayOutputStream();
	 FileOutputStream in=new FileOutputStream("d://temp.txt");
	 String hh="vishu is my name";
	 
    byte[]ii=hh.getBytes();
	in.write(ii);
    
	ByteArrayInputStream b=new ByteArrayInputStream(ii);
	
FileInputStream f=new FileInputStream("d://temp.txt");

  int i=0;
  while((i=f.read())!=-1) {
	  
	  System.out.println((char)i);
  }




}
}
