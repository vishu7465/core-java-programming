import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class dataStream {
public static void main(String g[]) throws IOException {
	DataOutputStream u=new DataOutputStream(new FileOutputStream("e://tem.txt"));
u.writeInt(123456);
	
	DataInputStream d=new DataInputStream(new FileInputStream("d://temp.txt"));
	
	d.readInt();
}
}
