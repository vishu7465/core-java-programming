import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileOutPut {

	public static void main(String h[]) throws IOException  {
		
		FileOutputStream f=new FileOutputStream("d://temp.txt");
		String i="hello";
		byte[] ii=i.getBytes();
		f.write(ii);
	}
	
}
