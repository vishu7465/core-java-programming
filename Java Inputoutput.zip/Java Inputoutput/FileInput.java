import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInput {

	public static void main(String h[]) throws IOException {
		
		FileInputStream f=new FileInputStream("d://temp.txt");
		
		int i=0;
		while((i=f.read())!=-1) {
			
			System.out.print((char)i);
		}
		
	}
}
