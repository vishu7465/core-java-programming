import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjectStream  implements Serializable{
	
	
	
	private String name="";
    private int id;

	


public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

public static void main(String h[]) throws FileNotFoundException, IOException, ClassNotFoundException  {

	
	ObjectStream s=new ObjectStream();
     s.setName("vishal");	
	 s.setId(1234);
	
	ObjectOutputStream o=new ObjectOutputStream(new FileOutputStream("e://temp1.txt"));
	o.writeObject(s);
	ObjectInputStream ii=new ObjectInputStream(new FileInputStream("d://temp.txt"));
	ObjectStream s1=(ObjectStream)ii.readObject();
	
	System.out.println(s.getId());
	System.out.println(s.getName());
	
	
}
}