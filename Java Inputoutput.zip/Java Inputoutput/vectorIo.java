package exammm;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.SequenceInputStream;
import java.util.Enumeration;
import java.util.Vector;

public class vectorIo {
public static void main(String h[]) throws IOException {
	
	Vector<FileInputStream> v=new Vector<>();
	
	v.add( new FileInputStream("d://new folder//temp.txt"));
	v.add( new FileInputStream("d://new folder//temp1.txt"));
	
	v.add( new FileInputStream("d://new folder//temp2.txt"));
	
	v.add( new FileInputStream("d://new Folder//temp3.txt"));
	
	
	Enumeration e =v.elements();
	
	SequenceInputStream ss=new SequenceInputStream(e);
	
	int i=0;
	while((i=ss.read())!=-1) {
		
		System.out.print((char)i);
		
	}
	
}
	
}
