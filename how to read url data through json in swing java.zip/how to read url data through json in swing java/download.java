package practises;

import java.awt.TextArea;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JTextArea;

class downloadfile{

	int flag=0;
	
	public synchronized void downloadfile(String url,JTextArea ta) throws IOException {
		
		
		try{
			URL u=new URL(url);
		
		
		HttpURLConnection hr=(HttpURLConnection)u.openConnection();
	
		
		InputStream io=hr.getInputStream();
		
		BufferedReader bf=new BufferedReader(new InputStreamReader(io));
		
		String hh=bf.readLine();
		
		StringBuffer sb=new StringBuffer();
		
		while(hh!=null) {
			
			sb.append(hh).append("\n");
			
			hh=bf.readLine();
		}
		
		ta.setText(sb.toString());
		}catch(Exception e) {
			
		}
	
		flag=1;
		notify();
	}
	
	

	


public synchronized String success() {
	if(flag==0) {
	try {
	wait();
	}catch(Exception e) {
		
		
	}

}return "success";	
}

}

class download{
	
	public static void main(String[] args) {
		
		
	}
}
