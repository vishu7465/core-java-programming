
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class test {
	 Connection con;
	 {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3303/job","root","root");
	PreparedStatement ps=con.prepareStatement("insert into jobs values ('vishu','vishudrayan@gmail.com')");
		
	ps.executeUpdate();
	con.close();
	
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		}

}
